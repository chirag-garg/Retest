package com.cg.mra.dao;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.InvalidAccountNumber;

public interface IAccountDao {
	public Account getAccountDetails(String mobileNo) throws InvalidAccountNumber;

	public double rechargeAccount(String mobileNo, double rechargeAmount) throws InvalidAccountNumber;

}
