package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.service.AccountServiceImpl;
import com.cg.mra.service.IAccountService;

public class MainUI
{
	public static void main(String args[])
	{
		IAccountService iAccountService=new AccountServiceImpl();
		String mobile;
		double amount;
		@SuppressWarnings("resource")
		Scanner scanner=new Scanner(System.in);
		while(true)
		{
			System.out.println("1) Account Balance Enquiry\n2) Recharge Amount\n3) Exit\nEnter your choice");
			int choice=scanner.nextInt();
			switch(choice)
			{
				case 1:
					System.out.println("Enter Mobile No : ");
					mobile=scanner.next();
					try
					{
						System.out.println("Your Current Balance is Rs. "+iAccountService.getAccountDetails(mobile).getAccountBalance());
					}
					catch(Exception exception)
					{
						System.out.println(exception.getMessage());
					}
					break;
				case 2:
					System.out.println("Enter Mobile No : ");
					mobile=scanner.next();
					System.out.println("Enter Recharge Amount : ");
					amount=scanner.nextDouble();
					try
					{
						System.out.println("Your Account Recharged Successfully\nHello "+iAccountService.getAccountDetails(mobile).getCustomerName()+" ,Available Balance is "+iAccountService.rechargeAccount(mobile, amount));
					}
					catch(Exception exception)
					{
						System.out.println(exception.getMessage());
					}
					break;
				case 3:
					System.exit(0);
				default:
					System.out.println("You have entered a wrong choice\n");
			}	
		}
	}
}