package com.cg.mra.test;

import org.junit.Before;
import org.junit.Test;

import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.dao.IAccountDao;
import com.cg.mra.exception.InvalidAccountNumber;

public class Junit {
	IAccountDao dao = new AccountDaoImpl();

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void test() throws InvalidAccountNumber {

		dao.getAccountDetails("9010210131");
	}

	@Test
	public void test2() throws InvalidAccountNumber {

		dao.rechargeAccount("9823920123", 100);
	}

	@Test(expected = InvalidAccountNumber.class)
	public void test3() throws InvalidAccountNumber {
		dao.getAccountDetails("9259693817");

	}

	@Test(expected = InvalidAccountNumber.class)
	public void test4() throws InvalidAccountNumber {

		dao.rechargeAccount("7520303211", 100);
	}

}
