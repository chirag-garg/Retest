package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.InvalidAccountNumber;

public interface IAccountService {
	Account getAccountDetails(String mobileNo) throws InvalidAccountNumber;

	double rechargeAccount(String mobileNo, double rechargeAmount) throws InvalidAccountNumber;
}
