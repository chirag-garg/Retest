package com.cg.mra.service;

import java.util.regex.Pattern;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.dao.IAccountDao;
import com.cg.mra.exception.InvalidAccountNumber;

public class AccountServiceImpl implements IAccountService
{
	IAccountDao iAccountDao=new AccountDaoImpl();
	@Override
	public Account getAccountDetails(String mobile) throws InvalidAccountNumber
	{
		if(Pattern.matches("[0-9]{10}", mobile))
		{
			return (iAccountDao.getAccountDetails(mobile));
		}
		else
		{
			throw new InvalidAccountNumber("Mobile Number should be of 10 digits\n");
		}
	}

	@Override
	public double rechargeAccount(String mobile, double rechargeAmount) throws InvalidAccountNumber
	{
		if(Pattern.matches("[0-9]{10}", mobile))
		{
			return (iAccountDao.rechargeAccount(mobile, rechargeAmount));
		}
		else
		{
			throw new InvalidAccountNumber("Mobile Number should be of 10 digits\n");
		}
	}

}
